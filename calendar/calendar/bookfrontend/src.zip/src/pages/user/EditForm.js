import React from 'react';
 
function EditForm() {
  return (
    <div>
            make a kind of discution board for people to let everyone know what
            updates/ things are going on in the office. 
    </div>
  );
}

export default EditForm;