import React from 'react';
 
function UpdateForm() {
  return (
    <div>
       Update page
    </div>
  );
}

export default UpdateForm;
