import React from 'react';
 
function LoginForm() {
  return (
    <div>
            This is not a page it is a log out that will then take to a login page
    </div>
  );
}

export default LoginForm;
