
import React from 'react';
import { Col, Container, Row , Button} from 'react-bootstrap';

function CovidForm() {
  return (
    <div style={{justifyContent: 'center'}}>
      
      <Container>
 
  <Row>
    <Col>1 of 3</Col>
    <Col>  
    <Button href="https://www.kcmo.gov/city-hall/departments/health/coronavirus-covid-19-kcmo-information-and-response/reopen" variant="secondary">City Guidelines for Covid</Button>{' '}
                
            </Col>
    <Col>3 of 3</Col>
  </Row>
</Container>

    </div>
  );
}

export default CovidForm;

